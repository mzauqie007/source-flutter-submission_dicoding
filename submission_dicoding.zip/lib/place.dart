import 'listmovie.dart';

final listMoview = [
  DrawListMovie(
      diterbitkan: 2021,
      imdb: 7,
      name: 'No Time To Die',
      price: 4200,
      imageAssets:
          'https://i0.wp.com/www.telusur.id/wp-content/uploads/2021/10/bond.jpg?w=1000&ssl=1',
      description:
          'Bond telah meninggalkan layanan aktif dan menikmati kehidupan yang tenang di Jamaika. Kedamaiannya berumur pendek ketika teman lamanya Felix Leiter dari CIA muncul meminta bantuan. Misi untuk menyelamatkan seorang ilmuwan yang diculik ternyata jauh lebih berbahaya dari yang diharapkan, membawa Bond ke jejak penjahat misterius yang dipersenjatai dengan teknologi baru yang berbahaya. —Gambar Universal'),
  DrawListMovie(
      diterbitkan: 2016,
      imdb: 6,
      name: 'Jason Bourne 2016',
      price: 4200,
      imageAssets:
          'https://m.media-amazon.com/images/M/MV5BNGJlYjVkMjQtN2NlZC00NTJhLThmZjItMTRlZDczMmE3YmI3XkEyXkFqcGdeQXVyMzI0NDc4ODY@._V1_.jpg',
      description:
          'Jason Bourne kembali diburu oleh CIA. Ini dimulai ketika Nicky Parsons, mantan agen CIA yang membantu Bourne, yang bangkrut dan sekarang bekerja dengan seorang pelapor dan berusaha mengungkap operasi hitam CIA. Nicky meretas CIA dan mengunduh semua yang ada di Black Ops mereka, termasuk Treadstone di mana Bourne menjadi bagiannya. Dan Heather Lee, seorang agen CIA, menemukan peretasan tersebut dan memberitahukannya kepada Direktur CIA Dewey, orang di balik Black Ops. Dia memerintahkan Parsons ditemukan dan, semoga, Bourne juga.'),
  DrawListMovie(
      diterbitkan: 2018,
      imdb: 8,
      name: 'Avengers: endgame',
      price: 4200,
      imageAssets:
          'https://upload.wikimedia.org/wikipedia/id/0/0d/Avengers_Endgame_poster.jpg',
      description:
          'Setelah peristiwa dahsyat di Avengers: Infinity War (2018), alam semesta hancur akibat ulah Mad Titan, Thanos. Dengan bantuan sekutu yang tersisa, Avengers harus berkumpul sekali lagi untuk membatalkan tindakan Thanos dan membatalkan kekacauan di alam semesta, tidak peduli konsekuensi apa yang mungkin terjadi, dan tidak peduli siapa yang mereka hadapi'),
  DrawListMovie(
      diterbitkan: 2018,
      imdb: 8,
      name: 'Avengers: infinity war',
      price: 4200,
      imageAssets:
          'https://m.media-amazon.com/images/M/MV5BMjMxNjY2MDU1OV5BMl5BanBnXkFtZTgwNzY1MTUwNTM@._V1_.jpg',
      description:
          'Saat Avengers dan sekutunya terus melindungi dunia dari ancaman yang terlalu besar untuk ditangani oleh pahlawan mana pun, bahaya baru muncul dari bayang-bayang kosmik: Thanos. Seorang lalim dari keburukan antargalaksi, tujuannya adalah untuk mengumpulkan keenam Batu Keabadian, artefak dengan kekuatan yang tak terbayangkan, dan menggunakannya untuk memaksakan kehendaknya yang menyimpang pada semua kenyataan. Segala sesuatu yang telah diperjuangkan para Avengers telah mengarah pada momen ini, nasib bumi dan keberadaannya semakin tidak menentu'),
  DrawListMovie(
      diterbitkan: 2017,
      imdb: 5,
      name: 'OKJA 2017',
      price: 4200,
      imageAssets:
          'https://m.media-amazon.com/images/M/MV5BMjQxMTcxNDgxN15BMl5BanBnXkFtZTgwOTczNTIzMjI@._V1_FMjpg_UX1000_.jpg',
      description:
          'Selama 10 tahun yang indah, Mija muda (An Seo Hyun) telah menjadi pengasuh dan pendamping tetap Okja—hewan besar dan teman yang bahkan lebih besar—di rumahnya di pegunungan Korea Selatan. Tapi itu berubah ketika konglomerat multinasional milik keluarga Mirando Corporation mengambil Okja untuk diri mereka sendiri dan membawanya ke New York, di mana CEO Lucy Mirando (Tilda Swinton) yang terobsesi dengan citra dan mempromosikan diri memiliki rencana besar untuk teman tersayang Mija. Tanpa rencana khusus dan niat tunggal, Mija memulai misi penyelamatan, namun perjalanannya yang menakutkan dengan cepat menjadi lebih rumit ketika dia bertemu dengan kelompok kapitalis, demonstran, dan konsumen yang berbeda, masing-masing berjuang untuk mengendalikan nasib Okja. ...sementara yang ingin dilakukan Mija hanyalah membawa pulang temannya'),
  DrawListMovie(
      diterbitkan: 2018,
      imdb: 6,
      name: 'ANT-MAN AND THE WASP: QUANTUMANIA (2023)',
      price: 4200,
      imageAssets:
          'https://m.media-amazon.com/images/M/MV5BODZhNzlmOGItMWUyYS00Y2Q5LWFlNzMtM2I2NDFkM2ZkYmE1XkEyXkFqcGdeQXVyMTU5OTA4NTIz._V1_.jpg',
      description:
          'Scott Lang dan Hope Van Dyne, bersama dengan Hank Pym dan Janet Van Dyne, menjelajahi Alam Kuantum, tempat mereka berinteraksi dengan makhluk aneh dan memulai petualangan yang melampaui batas dunia. apa yang mereka pikir mungkin.'),
  DrawListMovie(
      diterbitkan: 2021,
      imdb: 6,
      name: 'THE ADAM PROJECT (2022)',
      price: 4200,
      imageAssets:
          'https://m.media-amazon.com/images/M/MV5BOWM0YWMwMDQtMjE5NS00ZTIwLWE1NWEtODViMWZjMWI2OTU3XkEyXkFqcGdeQXVyMTEyMjM2NDc2._V1_FMjpg_UX1000_.jpg',
      description:
          'Adam Reed, usia 12 tahun, dan masih berduka atas kematian mendadak ayahnya setahun sebelumnya, berjalan ke garasinya suatu malam untuk menemukan seorang pilot yang terluka bersembunyi di sana. Pilot misterius ini ternyata adalah versi dirinya yang lebih tua dari masa depan, di mana perjalanan waktu masih dalam masa pertumbuhan. Dia telah mempertaruhkan segalanya untuk kembali tepat waktu dalam misi rahasia. Bersama-sama mereka harus memulai petualangan ke masa lalu untuk menemukan ayah mereka, mengatur hal-hal yang benar, dan menyelamatkan dunia. '),
  DrawListMovie(
      diterbitkan: 2012,
      imdb: 7,
      name: 'Skyfall 2012',
      price: 4200,
      imageAssets:
          'https://m.media-amazon.com/images/M/MV5BMWZiNjE2OWItMTkwNy00ZWQzLWI0NTgtMWE0NjNiYTljN2Q1XkEyXkFqcGdeQXVyNzAwMjYxMzA@._V1_.jpg',
      description:
          'Ketika tugas terbaru James Bond (Daniel Craig) berjalan buruk dan Agen di seluruh dunia terungkap, MI6 diserang, memaksa (M Dame Judi Dench) untuk merelokasi agensi tersebut. Peristiwa ini menyebabkan wewenang dan posisinya ditantang oleh Gareth Mallory (Ralph Fiennes), Ketua Komite Intelijen dan Keamanan yang baru. Dengan MI6 yang kini dikompromikan baik dari dalam maupun luar, M hanya memiliki satu sekutu yang dapat ia percayai: Bond. 007 turun ke bayang-bayang, hanya dibantu oleh agen lapangan, Miss Eve Moneypenny (Naomie Harris), mengikuti jejak Tiago Rodriguez yang misterius, alias Raoul Silva (Javier Bardem), yang motif mematikan dan tersembunyinya belum terungkap.'),
];
