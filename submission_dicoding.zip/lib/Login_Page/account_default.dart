class User {
  String userName = 'Gina';
  String password = '1';
}
