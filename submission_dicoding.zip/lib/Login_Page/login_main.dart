import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'account_default.dart';
import 'package:flutter_application_1/Tab_Page/home.dart';

class LoginPage extends StatefulWidget {
  LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _username = TextEditingController();

  final TextEditingController _password = TextEditingController();
  bool _passwordObs = false;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          margin: const EdgeInsets.all(30),
          child: const Center(
            child: Text('USER LOGIN',
                style: TextStyle(
                    fontSize: 50,
                    fontWeight: FontWeight.bold,
                    color: Colors.white)),
          ),
        ),
        const SizedBox(
          height: 20,
        ),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 300,
            height: 250,
            color: Colors.white,
            child: Column(
              children: [
                Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      children: [
                        TextField(
                          controller: _username,
                          decoration: const InputDecoration(
                              labelText: 'Username',
                              border: OutlineInputBorder()),
                        ),
                        const SizedBox(height: 15),
                        TextField(
                          controller: _password,
                          obscureText: _passwordObs,
                          decoration: InputDecoration(
                              labelText: 'Password',
                              suffixIcon: IconButton(
                                onPressed: () {
                                  setState(() {
                                    _passwordObs = !_passwordObs;
                                  });
                                },
                                icon: Icon(_passwordObs
                                    ? Icons.visibility_off
                                    : Icons.visibility),
                              ),
                              border: const OutlineInputBorder()),
                        ),
                        const SizedBox(height: 15),
                        SizedBox(
                          width: 100,
                          height: 50,
                          child: ElevatedButton(
                              onPressed: () {
                                setState(() {
                                  if (_username.text == User().userName &&
                                      _password.text == User().password) {
                                    Navigator.pushReplacement(context,
                                        MaterialPageRoute(
                                      builder: (context) {
                                        return HomePage();
                                      },
                                    ));
                                  } else {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(
                                            duration: Duration(seconds: 3),
                                            content: Text(
                                                'Username atau Password salah!')));
                                  }
                                });
                              },
                              child: const Text(
                                'Masuk',
                                style: TextStyle(fontSize: 20),
                              )),
                        )
                      ],
                    ))
              ],
            ),
          ),
        )
      ],
    ));
  }
}
