class DrawListMovie {
  String? name, imageAssets, description;
  int? price, imdb, diterbitkan;
  DrawListMovie(
      {required this.name,
      required this.price,
      required this.imageAssets,
      required this.description,
      required this.diterbitkan,
      required this.imdb});
}
