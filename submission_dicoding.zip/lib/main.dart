import 'package:flutter/material.dart';
import 'Login_Page/login_main.dart';

class ExutedProgram extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: const Color.fromARGB(255, 41, 155, 248),
        body: LoginPage(),
      ),
    );
  }
}

void main() => runApp(ExutedProgram());
