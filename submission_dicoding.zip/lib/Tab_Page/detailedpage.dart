import 'package:flutter/material.dart';
import 'package:flutter_application_1/listmovie.dart';

// ignore: must_be_immutable
class DetailedPageMovie extends StatefulWidget {
  DrawListMovie? movies;
  DetailedPageMovie(this.movies, {super.key});

  @override
  State<DetailedPageMovie> createState() => _DetailedPageMovieState();
}

class _DetailedPageMovieState extends State<DetailedPageMovie> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.get_app),
        onPressed: () {
          setState(() {
            showDialog(
              context: context,
              builder: (context) {
                return AlertDialog(
                  title: const Text('Informasi: '),
                  content: const Text('Sewa Film ini Berhasil!'),
                );
              },
            );
          });
        },
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(
                    'Sewa Film ${widget.movies!.name!} Subtittle Bahasa Indonesia'
                        .toUpperCase(),
                    style: const TextStyle(
                        fontSize: 25, fontWeight: FontWeight.bold)),
              ),
              Card(
                child: SizedBox(
                  width: 350,
                  height: 270,
                  child: Row(
                    children: [
                      ClipRRect(
                          borderRadius: BorderRadius.circular(10),
                          child: Padding(
                            padding: const EdgeInsets.all(5.0),
                            child: Image.network(
                              widget.movies!.imageAssets!,
                              width: 175,
                              height: 400,
                            ),
                          )),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Column(
                          children: [
                            Text('IMDB Rating        ${widget.movies!.imdb!} ',
                                textAlign: TextAlign.left),
                            const SizedBox(height: 5),
                            Text(
                                'Diterbitkan     ${widget.movies!.diterbitkan!.toString()} ',
                                textAlign: TextAlign.left),
                            const SizedBox(height: 200),
                            Text('BIAYA SEWA  ${widget.movies!.price!} ',
                                textAlign: TextAlign.left,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                )),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      'Synopsis'.toUpperCase(),
                      style: const TextStyle(
                          fontSize: 30, fontWeight: FontWeight.bold),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      width: 300,
                      height: 5,
                      color: Colors.amberAccent,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(widget.movies!.description!,
                        textAlign: TextAlign.justify,
                        style: const TextStyle(fontSize: 17)),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
