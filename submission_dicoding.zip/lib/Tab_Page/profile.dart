import 'package:flutter/material.dart';

class PageProfile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.all(8.0),
      child: Column(
        children: [
          Card(
            child: SizedBox(
              width: 340,
              height: 200,
              child: Column(
                children: [
                  Text(
                    'Aboutme',
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text(
                        'Halo.. Nama saya M. ZAUQI FIRDAUS, saya sangat pemula dalam flutter, dan ini adalah aplikasi pertama saya tentunya jauh dari kata sempurna hehehe.Kebetulan ini adalah untuk tugas akhir Dicoding :)', textAlign: TextAlign.center,),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
