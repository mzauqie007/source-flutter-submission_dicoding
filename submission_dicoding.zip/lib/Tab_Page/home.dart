import 'package:flutter/material.dart';
import 'package:flutter_application_1/listmovie.dart';
import 'package:flutter_application_1/place.dart';
import 'profile.dart';
import 'detailedpage.dart';

// ignore: must_be_immutable
class HomePage extends StatelessWidget {
  List<Color> myColor = [
    const Color.fromARGB(186, 22, 245, 14),
    const Color.fromARGB(213, 74, 8, 230),
    const Color.fromARGB(212, 255, 32, 32)
  ];
  List<Tab> tabBar = [
    const Tab(
      icon: Icon(Icons.playlist_add),
      text: 'Daftar Movie',
    ),
    const Tab(
      icon: Icon(Icons.account_circle),
      text: 'Profile',
    ),
  ];

  List<Widget> itemTabBar = [const DrawListItem(), PageProfile()];
  HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
          appBar: AppBar(
              title: const Text('LAYAR-MOVIE'),
              bottom: TabBar(tabs: tabBar),
              flexibleSpace: Container(
                decoration:
                    BoxDecoration(gradient: LinearGradient(colors: myColor)),
              )),
          backgroundColor: const Color.fromARGB(255, 223, 223, 223),
          body: TabBarView(children: itemTabBar)),
    );
  }
}

class DrawListItem extends StatefulWidget {
  const DrawListItem({
    super.key,
  });

  @override
  State<DrawListItem> createState() => _DrawListItemState();
}

class _DrawListItemState extends State<DrawListItem> {
  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: listMoview.length,
      itemBuilder: (context, index) {
        final DrawListMovie movie = listMoview[index];
        return InkWell(
          onTap: () {
            setState(() {
              Navigator.push(context, MaterialPageRoute(
                builder: (context) {
                  return DetailedPageMovie(movie);
                },
              ));
            });
          },
          splashColor: const Color.fromARGB(255, 13, 252, 33),
          highlightColor: Colors.amberAccent,
          child: Card(
            child: Container(
              width: 130,
              height: 100,
              color: const Color.fromARGB(255, 255, 255, 255),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.network(movie.imageAssets!),
                  Expanded(
                      child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(movie.name!,
                            style: const TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 18)),
                        const Text(
                          'Synopsis',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        Expanded(
                            flex: 2,
                            child: Text(
                              movie.description!,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 3,
                            )),
                      ],
                    ),
                  ))
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
